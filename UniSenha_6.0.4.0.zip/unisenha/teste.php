<form action="senha.php" method="post">
  Chave: <input type="text" name="chave" value="4azvW6666rm6m6n6m6"><br>  
  Posto: <input type="text" name="posto" value="01"><br>
  Botoeira: <input type="text" name="botoeira" value="001"><br>
  Destino: <input type="text" name="destino" value="atendimento"><br>  
  Botao: <input type="text" name="botao" value="1"><br>  
  Paciente: <input type="text" name="paciente" value=""><br>  
  Fila Coleta: <input type="text" name="filacoleta" value=""><br> 
  <input type="submit" value="Submit">
</form>
