<?php
 	
	const VERSAO_ATUAL = '2.0';
 	//r: Atalho - Encripta string no formato padr�o de comunica��o Uniware
	function hex_encode($text){
	 return strtoupper(trim( str_to_hex(SoftEncode($text)) ));
	}

  	//r: Atalho - Decodifica criptografia padr�o uniware
	function hex_decode($text){
	 $tmp = hex_to_str($text);
	 $tmp = SoftEncode($tmp, true);
	 return $tmp;
	}
	/*
	O procedimento SoftEncode tem como finalidade a criptografia leve de dados
	que necessitem ser mantidos no formato string por qualquer motivo.

	Obs.: N�o alterar este c�digo sem que a mesma altera��o seja feita no c�digo Delphi.
	*/
	function SoftEncode($str,$decode = false){
	 $result = "";
	 if (empty($str)) {
	    return "";
	 }else{
	   if ($decode === true) {
		  //r: Decodificar
	      $Key2   = 'IJKL=ABCDEFGHMNOPQRSTUVW\XYZabcdefghijklmnopqr/stuvxz1234567890.';
	      $Key1   = 'S/TUVWXYZabuvxz1=234ABCDEFGHIJKLMN890.OPQRc\defghijklmnopqrst567';
	   }else{
		  //r: Codificar
	      $Key1   = 'IJKL=ABCDEFGHMNOPQRSTUVW\XYZabcdefghijklmnopqr/stuvxz1234567890.';
	      $Key2   = 'S/TUVWXYZabuvxz1=234ABCDEFGHIJKLMN890.OPQRc\defghijklmnopqrst567';
	   }

	   for ($i = 0;$i < strlen($str);$i++) {
		 $j = strpos($Key1, $str{$i} );
		 if ($j !== false) {
		    if (empty($result)){
		       if ($Key2{$j} != "0"){
			      $result = $Key2{$j};
	           }else{
	              $result = '~0';
	           }
		    }else{
			   $result .= $Key2{$j};
		    }
		 }else{
		   $result .= $str{$i};
		 }
	   }

	 }
	 if (strlen($result) > 0 && $result{0} == '~'){
	    $result = substr($result,1);
	 }
	 return $result;
	}    

	function ajcod($valor,$tamanho){
		while (strlen($valor) < $tamanho) {
			$valor = '0' . $valor;
		}
		return $valor;
	}

	function Validar($nome, $obrigatorio) {	
		$valor = filter_input(INPUT_POST, $nome);
		if (!$valor) {
			if ($obrigatorio){
				echo "ERRO|Nao foram enviados todos os dados para processar($nome).";
		    } else {
				return '';
			}
			exit;
		} else {
			return $valor;
		}
	}

	function ValidarPosto($con, $aPosto) {	
		$result = $con->query("SELECT CVALOCOSI 
								 FROM LB_COSI
							    WHERE CCODICOSI = 'CADPOSTO'");		
		if ($result) {		
			if ($row = $result->fetch(PDO::FETCH_OBJ)) {				
				if (($row->CVALOCOSI != '01') && ($row->CVALOCOSI <> $aPosto)) {
					echo "ERRO|Posto Inv�lido.";
					exit;
				} elseif ($aPosto <> '01') {
					$stmt = $con->prepare("SELECT CINFOPOST
											 FROM LB_POST
											WHERE CCODIPOST = :CCODIPOST ");
					$stmt->bindParam('CCODIPOST',$aPosto);
					if ($stmt->execute()) {
						if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
							if ($row->CINFOPOST == 'S') {
								echo "ERRO|O posto n�o pode ser informatizado.";
								exit;
							}
						}
					} else {
						echo "ERRO|Erro ao buscar na LB_POST";
						exit;
					}					
				} 
			} else {
				echo "ERRO|N�o encontrado posto na LB_COSI.";
				exit;
			}
		} else {
			echo "ERRO|Erro ao buscar posto na lb_cosi.";
			exit;
		}
	}

	function Reqseq ($con, $seq, $zerarSeq = false){
		$sequencia = array();
		$contador = '';
		$result = $con->prepare("SELECT CSEQ, NPROX as contador 
								   FROM ULIBSEQ
							      WHERE CSEQ = :CSEQ");	
		$result->bindParam('CSEQ',$seq);
		if ($result->execute()) {
   			$sequencia = $result->fetch(PDO::FETCH_ASSOC);
   			if ($sequencia) {
	   			if (count($sequencia)) {
	   				$contador = $sequencia['contador'];
	   				$cseq = $sequencia['CSEQ'];
	   			}
	   			if ($zerarSeq) {
					$result = $con->prepare("UPDATE ULIBSEQ        
										      SET NPROX = 1,       
					  				              NINC =  1       
										    WHERE CSEQ = :CSEQ");
					$result->bindParam('CSEQ',$seq);	
					if(!$result -> execute()) {
	            		$con->rollBack();
	            		echo 'ERRO|Não foi possivel atualizar a sequencia: '.$seq;			
						exit;
					}else {
						$contador = 1;
					}
				} else {
					$result = $con->prepare("UPDATE ULIBSEQ        
										      SET NPROX = NPROX+1              
										    WHERE CSEQ = :CSEQ");
					$result->bindParam('CSEQ',$seq);	
					if(!$result -> execute()) {
	            		$con->rollBack();
	            		echo 'ERRO|Não foi possivel atualizar a sequencia: '.$seq;			
						exit;
					}
				}

   			} else {
				$result = $con->prepare("INSERT INTO ULIBSEQ (CSEQ, NINC, NPROX)
								                    VALUES (:CSEQ, 1, 2)");
				$result->bindParam('CSEQ',$seq);	
				if(!$result -> execute()) {
	            	$con->rollBack();
	            	echo 'ERRO|Não foi possivel criar a sequencia: '.$seq;			
					exit;
				}else {
					$contador = 1;
				}
			}	
   		}
		return $contador;
	}

	function ConfigSis($con, $param, $valorGraveParametro = ''){
		$valor = '';
		$result = $con->prepare("SELECT CVALOCOSI 
								 FROM LB_COSI
								WHERE CCODICOSI = :CCODICOSI");
		$result->bindParam('CCODICOSI',$param);
		if ($result->execute()) {
			$config = $result->fetch(PDO::FETCH_ASSOC);
			   		if ($config){		
   			$valor = $config['CVALOCOSI'];
	   	 	}
		}
   	 	
        if ($valorGraveParametro != ''){
			if($valor != '') {
				$result2 = $con->prepare("UPDATE LB_COSI
										   SET CVALOCOSI = :CVALOCOSI
										 WHERE CCODICOSI = :CCODICOSI ");
				$result2->bindParam('CVALOCOSI',$valorGraveParametro);
				$result2->bindParam('CCODICOSI',$param);
				if(!$result2->execute()) {
	            	$con->rollBack();
	            	echo 'ERRO|Não foi possivel atualizar a configuração: '.$param;			
					exit;
				}
			}else{
				$result2 = $con->prepare("INSERT INTO LB_COSI(CCODICOSI, CVALOCOSI)
												 VALUES(:CCODICOSI, :CVALOCOSI)");	
	            $result2->bindParam('CVALOCOSI',$valorGraveParametro);
				$result2->bindParam('CCODICOSI',$param);
				if(!$result2->execute()) {
	            	$con->rollBack();
	            	echo 'ERRO|Não foi possivel criar a configuração: '.$param;			
					exit;
				}		
			} 
			$valor = Date('Y-m-d');
		}
		return $valor;
	}

	function validaVersao($con){
		$aMsg = '';
		$versaoUniSenha = ConfigSis($con, 'VERSAOMINIMAUNISENHA');
		$versaoUnilab   = ConfigSis($con, 'VERSAOSISTEMA');
		if ($versaoUnilab < '3.03.013'){
			$aMsg = 'ERRO|Versão do unilab inferior a 3.03.013. Entre em contato com a UNIWARE para realizar atualização.';			
		} elseif (($versaoUniSenha < '2.0')) {
			$aMsg = 'ERRO|Versão do Unisenha inferior a versão 2.0. Entre em contato com a UNIWARE para realizar atualização.';			
		} elseif ((VERSAO_ATUAL < '2.0') && (VERSAO_ATUAL <> '')){
			$aMsg = 'ERRO|Versão do Unisenha inferior a versão 2.0. Entre em contato com a UNIWARE para realizar atualização.';			
		}
	    return $aMsg; 
	}

	function horaAtual($usaFuso, $fusoHorario){		
		if ($usaFuso) {
			switch (substr($fusoHorario,4,3)) {
				case '-07':
				//;//-7
				case '-06':
					date_default_timezone_set('America/Denver'); //-6  
					break;
				case '-05':
					date_default_timezone_set('Brazil/Acre'); //-5           
					break;
				case '-04':
					date_default_timezone_set('America/Campo_Grande'); //-4           
					break;
				case '-02':
					date_default_timezone_set('Brazil/DeNoronha');//-2          
					break;
				default:
				date_default_timezone_set('America/Sao_Paulo'); //-3
			}    
		} else {
		date_default_timezone_set('America/Sao_Paulo'); //-3      
		}
		return date("Y-m-d H:i:s");  
	}

	$aChave = Validar('chave', true);		

	$CodAdm = strtoupper(substr(SoftEncode($aChave,true),5,5)); //do 6 ao 10 caracter
	require_once "../app/config/conexao.php";

	if (!isset($dsn)) {
		echo 'ERRO|Código Adm não encontrado para conexão';			
		exit;
	}
	
	$con = New PDO($dsn, 'UNIWARE', 'DBUCFGS');
	if (!$con) {
	    echo 'ERRO|Não foi possível conectar: ' . mysql_error();
	    exit;
	}	

	$MSg = validaVersao($con);
	if ($MSg != '') {
		echo $MSg;
		exit;
	}

	
	if (Validar('teste', false) == 'S') { 
		$aFilaColeta = Validar('filacoleta', false);
		
		if ($aFilaColeta != ''){	
			$result = $con->prepare("SELECT 1 FROM LB_FILACOL WHERE CCODIFILACOL = :CCODIFILACOL");
			$result->bindParam('CCODIFILACOL', $aFilaColeta);
			if ($result->execute()) {
				if ($result->fetch(PDO::FETCH_ASSOC)) {
					echo "OK";
					exit;
				} else {
					echo "ERRO|Fila de coleta configurada nao encontrada.";
					exit;
				}
			} else {
				echo "ERRO|Falha ao tentar validar a fila de coleta.";
				exit;
			}
			exit;	
		} else {
			echo "OK";
			exit;
		}
	}
	
	$aPosto      = Validar('posto', true);
	$aBotoeira   = Validar('botoeira', true);
	$aDestino    = Validar('destino', true);
	$aBotao      = Validar('botao', ($aDestino == 'atendimento'));
	$aPaciente   = Validar('paciente', ($aDestino == 'coleta'));
	$aFilaColeta = Validar('filacoleta', ($aDestino == 'coleta'));
	
	ValidarPosto($con, $aPosto);

	if ($aDestino == 'atendimento') {		

		//Inicia Transa��o para obter a proxima senha
		$con->beginTransaction();

		$result = $con->prepare("SELECT CCODIFILAATEND1,                       
									CPREFIXOBOTOEIRA1,                      
									EPRIORIDADEBOTOEIRA1,                   
									CCODIFILAATEND2,                        
									CPREFIXOBOTOEIRA2,                      
									EPRIORIDADEBOTOEIRA2,                   
									CCODIFILAATEND3,                        
									CPREFIXOBOTOEIRA3,                      
									EPRIORIDADEBOTOEIRA3,                   
									CCODIFILAATEND4,                        
									CPREFIXOBOTOEIRA4,                      
									EPRIORIDADEBOTOEIRA4                    
								FROM LB_BOTOEIRA                        
								WHERE CCODIBOTOEIRA      = :CCODIBOTOEIRA     
								AND CCODIPOST          = :CCODIPOST         ");
		$result->bindParam('CCODIBOTOEIRA',$aBotoeira);
		$result->bindParam('CCODIPOST',$aPosto);
		if ($result->execute()) {
			$botoeira = $result->fetch(PDO::FETCH_ASSOC);
			if ($botoeira) {
				$aFila         = $botoeira['CCODIFILAATEND'.$aBotao];
				$aPrefixo      = $botoeira['CPREFIXOBOTOEIRA'.$aBotao];
				$aPreferencial = $botoeira['EPRIORIDADEBOTOEIRA'.$aBotao];
			} else {
				echo "ERRO|botoeira não encontrada";
				exit;  
			}
		}


		$data = ConfigSis($con, 'DDATAFILAATEND');
		if ($data == ''){
			$data = ConfigSis($con, 'DDATAFILAATEND', Date('Y-m-d', strtotime(Date('Y-m-d') . ' -1 day')));
		}

		if ($data != '') {		
			$usaFuso = FALSE;
			$FusoHorario = '-03';
			$horarioVerao = FALSE;
			
			
			$q2 = " SELECT cvalocosi, ccodicosi
					FROM lb_cosi
				WHERE ccodicosi IN ( 'CADUSACONFFUSO',
									'CADFUSOHORARIO',
									'CADUSAHORARIOVERAO'); ";       
			
			$cosi = $con->prepare($q2);		   
			if ($cosi->execute()) {
				if ($linha = $cosi->fetchAll(PDO::FETCH_OBJ)) {
					foreach ($linha as $key => $value){
						if (strtoupper($value->ccodicosi) ==  'CADUSACONFFUSO'){
							$usaFuso = ($value->cvalocosi == 'S');
						}elseif (strtoupper($value->ccodicosi) ==  'CADFUSOHORARIO') {    
							$FusoHorario = $value->cvalocosi;    
						}elseif (strtoupper($value->ccodicosi) ==  'CADFUSOHORARIO') {    
							$horarioVerao = ($value->cvalocosi == 'S');
						}                    
					}   
				}
			}else {
				$con->rollBack();
				echo "ERRO|Erro ao buscar na lb_cosi";
				exit;       
			}

			$strDataHora = horaAtual($usaFuso, $FusoHorario);
			
			$contador      = Reqseq($con, 'LB_BOTOEIRAFILA'.$aFila.$aPrefixo.$aPosto);
			$reiniciaSenha = ! (ConfigSis($con, 'PEDIREINICIASENHA') == 'N'); 
			if (($data != Date('Y-m-d')) && ($reiniciaSenha)) {
				$stmt2 = $con->prepare(' SELECT CSEQ FROM ULIBSEQ             
										WHERE CSEQ LIKE "LB_BOTOEIRAFILA%" ');
				if ($stmt2->execute()) {
					$rowSeq = $stmt2->fetchAll(PDO::FETCH_ASSOC);
					if (count($rowSeq) > 0){
						foreach ($rowSeq as $key => $value) {
							Reqseq($con, $value['CSEQ'], true);
						}				 
					}	
				} else {
					echo "ERRO|Erro ao localizar os contadores da LB_BOTOEIRAFILA";
					exit;
				}
				$contador = Reqseq($con, 'LB_BOTOEIRAFILA'.$aFila.$aPrefixo.$aPosto);
				ConfigSis($con, 'DDATAFILAATEND',Date('Y-m-d'));
			} elseif ($contador > 999) {	
				Reqseq ($con, 'LB_BOTOEIRAFILA'.$aFila.$aPrefixo.$aPosto, true);
				$contador = Reqseq ($con, 'LB_BOTOEIRAFILA'.$aFila.$aPrefixo.$aPosto);	
			} 

			$CSENHAATEND = $aPrefixo . ajcod($contador,3);
			$ETIPOATEND = $aPreferencial;

			$atendSeq = Reqseq ($con,'LB_ATEND'.$aPosto);
			$CCODIATEND = ajcod($atendSeq,9);

			$q = "INSERT INTO LB_ATEND
					(CCODIPOST, CCODIATEND, CCODIFILAATEND, CSENHAATEND, 
					ETIPOATEND, ESTATUSATEND, DEMISSAOSENHAATEND, EREFILAATEND, EFINALIZADOTEMPOATEND,
					ULIBUINC, ULIBDINC)
				VALUES
					(:CCODIPOST, :CCODIATEND, :CCODIFILAATEND, :CSENHAATEND, 
					:ETIPOATEND, 'AA', :DATAHORA, 'N', 'N',
					'UNISENHA', :DATAHORA)";
				
			$stmt = $con->prepare($q);
			$stmt->bindParam('CCODIPOST',$aPosto);	
			$stmt->bindParam('CCODIATEND',$CCODIATEND);
			$stmt->bindParam('CCODIFILAATEND',$aFila);	
			$stmt->bindParam('CSENHAATEND',$CSENHAATEND);	
			$stmt->bindParam('ETIPOATEND',$ETIPOATEND);
			$stmt->bindParam('DATAHORA',$strDataHora, PDO::PARAM_STR);
			if (!$stmt->execute()) {
				$con->rollBack();
				echo "ERRO|Falha ao inserir na LB_ATEND. Por favor verifique se a configuração da fila está correta (fila, botoeira e posto de coleta).";
				exit;
			}	
			$con->commit(); 
			echo $CSENHAATEND . '|' . Date('d/m/Y H:i:s');
		}
	
	} elseif ($aDestino == 'coleta') {	
		
		$con->beginTransaction();
		$usaFuso = FALSE;
		$FusoHorario = '-03';

		$querySelect = "SELECT CCODIPOST, CCODIPEDI,          
								CCODIPEDIPRINC,                
								ESUSPENSOPEDI                  
						FROM LB_PEDI                        
						WHERE (CSTATUSEXPR = 'P' OR        
								CSTATUSEXPR = ''  OR        
								CSTATUSEXPR IS NULL)          
						AND ESUSPENSOPEDI IN ('N', 'P')
						AND EFILACOLPEDI = 'N'           
						AND CCODIPOSTPACI = :POST          
						AND CCODIPACI     = :PACI 
						AND DENTRPEDI >= DATE_SUB(CURDATE(), INTERVAL :LIMITEBUSCA DAY) ";  

		$queryJaEstaNaFila = "SELECT 1        
							    FROM LB_PEDI               
							   WHERE CCODIPOSTPACI = :POST 
							     AND CCODIPACI     = :PACI 
								 AND EFILACOLPEDI  = 'S'
								 LIMIT 1";
  
						
		$queryUpdate = " UPDATE LB_PEDI SET                    
								DFILACOLPEDI = :DFILACOLPEDI , 
								EFILACOLPEDI = 'S' ,         
								CCODIFILACOL = :CCODIFILACOL,  
								EFILACOLAPOSPEDI = 'N',      
								CCODIPOSTFILACOLPEDI = :POST   
					      WHERE CCODIPOST = :CCODIPOST         
							AND CCODIPEDI = :CCODIPEDI    ";

		$varLimite = ConfigSis($con, 'DIASBUSCACOLETAUNICHECKIN');
		if ($varLimite == '') {
			$varLimite = 90;
		}
		$result = $con->prepare($querySelect);  		
		$varpost = substr($aPaciente, 0, 2);		
		$varpaci = substr($aPaciente, 2, 8);	
		$result->bindParam('POST', $varpost);
		$result->bindParam('PACI', $varpaci);
		$result->bindParam('LIMITEBUSCA', $varLimite);
		$pedidos = array();
		if ($result->execute()) {				
			$rows = $result->fetchAll(PDO::FETCH_OBJ);
			if (count($rows) > 0){			 
				foreach ($rows as $row => $value){
					$pedidos[] = $value->CCODIPOST . $value->CCODIPEDI;
				}		
				$strDataHora = horaAtual($usaFuso, $FusoHorario);
				$retorno = 'OK';
				foreach($pedidos as $pedido){
					$update = $con->prepare($queryUpdate);
					$varpost = substr($pedido, 0, 2);
					$varpedi = substr($pedido, 2, 9);
					$update->bindParam('CCODIPOST', $varpost, PDO::PARAM_STR);
					$update->bindParam('CCODIPEDI', $varpedi, PDO::PARAM_STR);	
					$update->bindParam('CCODIFILACOL', $aFilaColeta, PDO::PARAM_STR);	
					$update->bindParam('POST', $aPosto, PDO::PARAM_STR);	
					$update->bindParam('DFILACOLPEDI', $strDataHora, PDO::PARAM_STR);	
					if ($update->execute()) {
						$retorno = $retorno . '|' . substr($pedido, 0, 2) . substr($pedido, 2, 9);						
					} else {
						$con->rollBack();
						echo "ERRO|Falha ao tentar colocar pedido na fila de coleta.";
						exit;
					}	
				}
				echo $retorno;
				$con->commit(); 
			} else {
			  $result = $con->prepare($queryJaEstaNaFila);  	
			  $varpost = substr($aPaciente, 0, 2);		
			  $varpaci = substr($aPaciente, 2, 8);					
			  $result->bindParam('POST', $varpost);
			  $result->bindParam('PACI', $varpaci);	  
			  if ($result->execute()) {	
				$rows = $result->fetchAll(PDO::FETCH_OBJ);	
			  	if (count($rows) > 0){	
					  echo "Paciente ja esta na fila de coleta.";
				} else {
					echo "ERROAPI|Paciente nao tem pedidos para serem incluidos na fila de coleta.|1";
					$con->rollBack();
				}
			  }			 
			}
		} else {
			echo "ERRO|Falha ao buscar pedidos do paciente.";
			$con->rollBack();
		}
	} else {
		echo "ERRO|Destino não informado ou diferente de.";
		$con->rollBack();
	}
?>